---
name: incident-triage
description: Work a live production incident — something is down, erroring, or slow right now. Use when the user reports a production outage, a spike in errors, a 500, a stuck queue, or says "prod is broken". Prioritises stopping the bleeding over finding the cause.
---

# Incident triage

**Restore service first. Understand it second.** Root-causing a live outage before
stopping it is the most common and most expensive mistake in this situation.

## 1. What is actually broken? (2 minutes, no code)

Pin down, in concrete terms:
- **Symptom** — what a user sees. "Checkout returns 500", not "checkout is broken".
- **Blast radius** — everyone, or one region / one tenant / one plan / one endpoint?
- **Started when** — the exact time. This is the single most useful fact you will get.
- **Still happening** — or already recovered?

If any of these is unknown, get it before doing anything else. Write them down.

## 2. What changed? (the cause, ~90% of the time)

Correlate the start time against:

```bash
git log --since="<start time minus 2h>" --oneline
gh run list --limit 20            # what deployed, and when
```

Also: a feature flag flipped, a config or env var change, a migration, an expired
certificate or token, a dependency auto-upgraded, a cloud provider incident, a cron
that only runs at this hour, a disk or quota that just filled.

**If a deploy lines up with the start time, that is your cause until proven otherwise.
Recommend rolling it back now.** Do not debug a bad deploy while it is live.

## 3. Stop the bleeding

Pick the fastest safe lever and say which you are recommending:
- roll back the deploy
- turn the feature flag off
- scale up / restart the unhealthy instances
- disable the failing non-critical path (degrade rather than fail)
- rate-limit or shed the traffic causing it

**A rollback is not a failure and it is not an admission of anything. It is the correct
first move.** Only fix forward if a rollback is impossible (an applied migration, for
example) — and say explicitly which case you are in.

## 4. Confirm recovery

Name the exact signal that proves it: the error rate, the health check, the specific
failing request replayed. "It looks fine now" is not confirmation. Check that the
metric is back to its *pre-incident* level, not merely better.

## 5. Only now: root cause

Use the **bug-hunter** subagent. Read the real stack traces and logs from the incident
window. Trace the bad value to where it first went wrong.

Also answer: **why did no test and no alert catch this?** That answer is worth more
than the fix.

## 6. Write it up

```
IMPACT:   <who, what, how long, how many>
TIMELINE: <started / detected / mitigated / resolved — with times>
CAUSE:    <the actual mechanism, file:line>
FIX:      <what was done to stop it>
WHY IT WAS NOT CAUGHT: <the missing test, alert, or review step>
FOLLOW-UPS: <concrete, assignable, each one preventing a recurrence>
```

Blameless. Name systems and gaps, never people. A write-up that blames someone
teaches the team to hide the next incident.

## Rules

- Never run a destructive or irreversible command during an incident without saying
  out loud what it does and what it cannot undo.
- Never change two things at once. You will not know which one worked, and if it gets
  worse you cannot back out cleanly.
- Log every action with its timestamp as you go. You will need it for the timeline and
  you will not remember.
