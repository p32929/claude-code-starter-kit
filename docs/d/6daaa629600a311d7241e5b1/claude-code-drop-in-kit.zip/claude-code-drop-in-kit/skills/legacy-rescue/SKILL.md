---
name: legacy-rescue
description: Safely change old code that has no tests, no docs, and nobody left who understands it. Use when the user must modify a legacy file, a function nobody dares touch, or code they describe as scary, ancient, or untested.
---

# Legacy rescue

The rule that makes this safe: **characterise before you change.** You cannot refactor
code whose behaviour you have not pinned down, because you have no way to tell a fix
from a regression.

## 1. Find out what actually uses it

```bash
git log --follow --oneline -- <file>        # why it exists, and who last understood it
grep -rn "<functionName>" --include=* .     # every caller
```

Also check for **dynamic** references — a string in a config, a route table, a DI
registration, a reflection call, a templated name. These do not show up in a plain
grep and they are how legacy code bites you.

If there are zero callers: the correct change is **delete it**. Check hard first
(dynamic refs, public API, a published package), then propose deletion.

## 2. Characterisation tests — before any edit

This is the whole technique, and skipping it is how people break production:

1. Write tests that assert what the code **currently does** — including behaviour that
   is obviously wrong. You are not testing correctness, you are recording reality.
2. Get real inputs: production logs, the existing callers, the database, a fixture file.
3. Run them. **They must pass against the unchanged code.** A characterisation test
   that fails at the start is a test you wrote wrong.
4. Note every surprising behaviour you just recorded. **Some caller almost certainly
   depends on the bug.** That is not a joke — it is the single most common cause of a
   "safe" legacy fix taking down production.

Now you have a safety net, and only now may you edit.

## 3. Understand before rewriting

Use the **explain** command or the **bug-hunter** subagent to map the flow. Write down
what each branch is for. Where the intent is genuinely unknowable, add a comment saying
so — `// unclear why this path exists; no caller found for cond X` is honest and useful,
and the next person will thank you.

**Do not rewrite it.** A rewrite of code you do not fully understand silently drops the
edge cases that were the entire reason it looks so strange.

## 4. Change in small, reversible steps

- One behaviour-preserving refactor at a time, tests green after every single one.
- Keep the public signature stable. If it must change, use a wrapper: new function with
  the new shape, old function delegates to it, migrate callers one at a time, delete the
  old one last.
- Behaviour changes go in a **separate commit** from refactors. Never mix them — if
  something breaks you must be able to tell which commit did it.

## 5. Leave it better than the minimum

When you are done: the characterisation tests stay (they are now real tests), the flow
gets a short comment at the top of the file, and anything you deliberately did not fix
gets a `TODO` naming what and why. Do not silently leave a landmine for the next person.

## Rules

- **Never delete code you do not understand just because it looks dead.** Prove it with
  a grep including dynamic references, or leave it.
- If a piece of behaviour seems wrong, check whether a caller depends on it before
  "fixing" it. Report it rather than quietly changing it.
- Report as: `characterisation tests added: N · behaviour changes: N · refactors: N ·
  suite before → after`. Numbers, not reassurance.
