---
name: spec-to-plan
description: Turn a vague feature request into a concrete implementation plan grounded in this codebase, before any code is written. Use when the user describes something they want built, pastes a ticket, or asks how to approach a feature.
---

# Spec to plan

The job is to make the work **boring and obvious** before a line is written. Most bad
features are bad because nobody asked the six questions below.

## 1. Read the codebase first

You cannot plan a change to code you have not read. Find and read:
- the closest existing feature of the same shape (there is almost always one)
- the data model this touches
- where such things get registered (router, schema, DI container, barrel export)

**Everything in the plan must name real files that exist.** A plan full of invented
paths is worthless.

## 2. Answer these six, explicitly

State the answer and mark it `(assumed)` if the user did not say. Assumptions surfaced
now are cheap; assumptions discovered in review are not.

1. **Who uses this, and what do they do today instead?**
2. **What is the smallest version that is genuinely useful?** Not the full vision — the
   first slice worth shipping.
3. **What is explicitly out of scope?** Write the list. This is the most valuable line
   in the whole plan.
4. **What existing behaviour could this break?**
5. **What happens when it fails?** Empty state, network error, partial write, a
   concurrent second click, permission denied.
6. **How will we know it works** once it is live?

## 3. The plan

```
GOAL: <one sentence, user-visible>
OUT OF SCOPE: <the list>
ASSUMPTIONS: <each one, marked, with the answer that would change the plan>

DATA:  <schema changes; migration needed? back-compat?>
API:   <endpoints/functions added or changed; breaking?>
UI:    <screens/components; states: loading, empty, error, success>

STEPS:
  1. <change> — files: <real paths> — verify: <command or click-path>
  2. ...
  (each step independently shippable and independently revertible)

RISKS: <what could go wrong, and the mitigation>
TESTS: <what must be covered for this to be trustworthy>
UNKNOWNS: <what you could not determine from the code — ask before step 1>
```

## Rules

- **Order the steps so the risky, uncertain part comes first.** If step 4 might be
  impossible, you want to find out before steps 1-3 are built on top of it.
- Every step gets a verification. A step you cannot verify is a step you cannot trust.
- No new dependency and no new abstraction unless the plan says why the existing ones
  do not work.
- **If the honest answer is "this feature should not be built", say so and why.** That
  is the highest-value output this skill can produce.
- Do not write code in this mode. The output is the plan. Stop when it is written and
  wait for a go-ahead.
