---
name: ship-it
description: Run the full pre-merge gate on a branch before opening a PR — review, tests, typecheck, lint, security, dead code, and the PR description. Use when the user says "ship it", "ready to PR", "is this mergeable", "pre-merge check", or asks what is left before merging.
---

# Ship It — the pre-merge gate

Run every gate below **in order**. Stop at the first BLOCKER and report it — do not
continue past a blocker and do not "note it for later". The point of a gate is that
it gates.

## 0. Scope

```bash
git branch --show-current
git diff --stat origin/HEAD...HEAD
git log --oneline origin/HEAD..HEAD
```

If the branch is the default branch, stop immediately: there is nothing to ship.

## 1. Is the diff one change?

Read the full diff. If it contains two unrelated changes, say so and recommend
splitting. A PR that does two things gets reviewed as neither.

## 2. Build, typecheck, lint

Run the project's real commands (from `package.json` scripts / Makefile / the CI
workflow — read the workflow so you use exactly what CI uses). Any failure is a
**BLOCKER**.

## 3. Tests

Run the suite. Then check the thing everyone skips: **does the diff add behaviour that
has no test?** New branch, new error path, new endpoint, fixed bug — each needs one.
Use the **test-writer** subagent to fill the gaps, then re-run.

A bug fix with no regression test is a **BLOCKER**. It will come back.

## 4. Review

Use the **code-reviewer** subagent on the diff.

Then run the check reviewers reliably miss: for every function whose **signature,
return shape, or thrown error** changed, grep the repo for its other callers and
verify each was updated. Any un-updated caller is a **BLOCKER**.

## 5. Security

Only if the diff touches user input, auth, a query, a file path, a shell command, a
network call, or a new dependency. Look for injection, a missing authz/ownership
check, a secret in the diff, or a typosquatted package. Anything exploitable is a
**BLOCKER**.

## 6. Leftovers

Grep the diff for: `console.log`, `debugger`, `print(`, `TODO`, `FIXME`, `XXX`,
commented-out code, a hardcoded localhost URL, a skipped or `.only` test. Each is a
one-line fix — fix them now.

## 7. Migration and config safety

If the diff contains a migration, a schema change, a renamed env var, or a changed
config default: is it backward compatible with the code currently running in
production? If not, it needs the expand/contract split (use the **migration-planner**
subagent) — this is a **BLOCKER**, and it is the one that causes real outages.

## 8. The PR

Write the description: what, why, how to test, risk. Call out explicitly anything a
reviewer would otherwise miss — a signature change, a migration, a new required env
var, a breaking API change.

## Report

```
SHIPPABLE: yes | no

  build ........ pass/fail
  typecheck .... pass/fail
  lint ......... pass/fail
  tests ........ N passed / M failed
  review ....... N blockers, M majors
  security ..... clean / N issues
  leftovers .... clean / N found
  migration .... n/a / back-compat / NEEDS SPLIT

BLOCKERS: <numbered, each with file:line and the fix. Empty if shippable.>
```

Never report `SHIPPABLE: yes` on the strength of a gate you did not actually run.
If you could not run one, write `not run — <why>` and mark the result `unknown`,
not `pass`.
