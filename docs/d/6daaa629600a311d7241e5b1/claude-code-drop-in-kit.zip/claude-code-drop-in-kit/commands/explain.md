---
description: Explain how a file, function, or flow actually works
argument-hint: "<file, function name, or 'how does X work'>"
allowed-tools: Read, Grep, Glob, Bash
---

Explain: $ARGUMENTS

## Your task

Read the real code first. Follow it across files — grep for definitions and callers rather than assuming what a name does.

Answer in this shape:

```
IN ONE SENTENCE: <what it does>

THE FLOW:
  1. <entry point — file:line> → ...
  2. ...
  (the actual call path, with file:line for each hop)

KEY DECISIONS: <the branches that matter and what drives each>

GOTCHAS: <the non-obvious parts — the thing that would surprise someone changing this>

WHERE TO CHANGE IT: <if I wanted to modify the behaviour, the exact file:line>
```

Rules:
- Cite `file:line` for every claim. No claim from memory or from the name of a thing.
- If two parts contradict each other, say so — that is usually a bug worth knowing about.
- No tutorial on the language or the framework. Assume I am a senior engineer who has simply never read this file.
