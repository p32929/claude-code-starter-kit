---
description: Security review of the current changes — real exploitable issues only
allowed-tools: Bash(git:*), Read, Grep, Glob
---

Changes:
!`git diff HEAD`

## Your task

Review only what changed, plus the code paths it touches. Look for issues that are **actually exploitable here**, not theoretical ones.

Check, in order:

1. **Injection** — user input reaching SQL, a shell command, `eval`, a file path, an HTML sink, or a template without parameterisation/escaping.
2. **Authz** — a new endpoint, route, or query that does not check *who is asking*. Specifically look for IDOR: does it check the record belongs to the caller, or only that the caller is logged in?
3. **Secrets** — keys, tokens, passwords, connection strings in code, in a committed config, or in a log line. Check the diff for anything matching a token shape.
4. **Unsafe deserialization / dynamic code** — `pickle`, `yaml.load`, `eval`, `Function()`, prototype pollution on a merge of user JSON.
5. **Path traversal** — user input in a filename or path without normalising and confining it to a base directory.
6. **Crypto misuse** — homemade crypto, MD5/SHA1 for passwords, a hardcoded IV, a non-constant-time comparison for a token.
7. **SSRF** — a server-side fetch to a user-supplied URL.
8. **Dependency** — a newly added package: check it is the real one and not a typosquat, and check its audit status.

## Output

```
[CRITICAL|HIGH|MEDIUM] <issue> — file:line
  EXPLOIT: <concrete: what an attacker sends, what they get>
  FIX: <the change>
```

Only report what you can write a concrete exploit sentence for. If there is nothing, say `No exploitable issues found in this diff` and list in one line what you checked. Do not pad with best-practice advice.
