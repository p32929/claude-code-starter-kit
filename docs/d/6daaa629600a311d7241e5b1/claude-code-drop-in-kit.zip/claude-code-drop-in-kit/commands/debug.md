---
description: Find the root cause of a bug from a symptom or a stack trace
argument-hint: "<the error, stack trace, or what is going wrong>"
allowed-tools: Bash, Read, Grep, Glob, Edit
---

The problem: $ARGUMENTS

Recent changes (the cause is often here):
!`git log --oneline -10`
!`git diff --stat HEAD~3..HEAD 2>/dev/null || echo "shallow history"`

## Your task

Use the **bug-hunter** subagent.

Before proposing any fix it must:
1. Reproduce the failure, or state plainly that it could not.
2. Trace the bad value back to where it *first* became wrong — not where it was noticed.
3. **Grep every caller** of the function it intends to change, and say whether they have the same bug. If they do, the fix goes in the shared code.

Then apply the minimal fix and run the verification. Report `ROOT CAUSE / WHY / BLAST RADIUS / FIX / VERIFY`.

Do not patch the symptom. If the honest answer is that the cause is not found, say so and list what was ruled out.
