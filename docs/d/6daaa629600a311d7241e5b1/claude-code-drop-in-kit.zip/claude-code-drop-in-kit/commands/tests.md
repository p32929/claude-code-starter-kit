---
description: Write tests for the code that changed, using the project's existing framework
argument-hint: "[optional: file or function to test]"
allowed-tools: Bash, Read, Grep, Glob, Write, Edit
---

Changed files:
!`git diff --name-only HEAD`

Target if I named one: $ARGUMENTS

## Your task

Use the **test-writer** subagent.

Constraints it must respect:
- Match the existing test framework and file layout. Read two existing tests first. Never introduce a new test library.
- Cover: the happy path, the edges that actually break (empty / null / zero / one / many / duplicate / unicode), and the error paths.
- Skip getters, constants, and framework behaviour.
- **Run the suite and paste the real output.** If a test fails, fix it or say which one fails and why.

Finish with: `N tests added, suite: X passed / Y failed`.
