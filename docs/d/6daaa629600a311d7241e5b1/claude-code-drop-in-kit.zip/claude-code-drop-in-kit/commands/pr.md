---
description: Open a pull request with a description written from the real commits and diff
argument-hint: "[optional: target branch]"
allowed-tools: Bash(git:*), Bash(gh:*)
---

Branch:
!`git branch --show-current`

Commits not on the base branch:
!`git log --oneline origin/HEAD..HEAD 2>/dev/null || git log --oneline -10`

Files changed:
!`git diff --stat origin/HEAD...HEAD 2>/dev/null || git diff --stat HEAD~5..HEAD`

Target branch if I specified one: $ARGUMENTS

## Your task

1. Push the branch if it has no upstream (`git push -u origin HEAD`).
2. Read the actual diff before writing anything.
3. Open the PR with `gh pr create`. Body structure:

```
## What
<2-4 sentences: what changed and why. No bullet-point dump of the diff.>

## Why
<the problem this solves, or the issue it closes — use "Closes #N" if there is one>

## How to test
<the exact commands or click-path a reviewer runs to see it work>

## Risk
<what could break, and what is NOT covered by this change>
```

4. **Call out anything a reviewer would miss**: a changed function signature, a migration, a config/env var that must be set before deploy, a breaking API change.
5. Report the PR URL.

If `gh` is not installed or not authenticated, say so and print the ready-to-paste title and body instead.
