---
description: Generate release notes from the commits since the last tag
argument-hint: "[optional: version number for this release]"
allowed-tools: Bash(git:*), Read, Edit, Write
---

Last tag: !`git describe --tags --abbrev=0 2>/dev/null || echo "no tags yet"`
Commits since then:
!`git log $(git describe --tags --abbrev=0 2>/dev/null || git rev-list --max-parents=0 HEAD)..HEAD --oneline`

Version I want: $ARGUMENTS

## Your task

1. Read the commits. Where a subject is uninformative (`fix stuff`, `wip`), read that commit's diff to find out what it actually did.
2. Group into: **Breaking**, **Added**, **Fixed**, **Changed**, **Security**. Drop anything a user cannot observe (refactors, test-only, formatting, dependency bumps with no user effect).
3. Write each line **from the user's point of view**, not the committer's: `Fixed export failing on files over 2 GB`, not `bumped buffer size in writer.ts`.
4. **Breaking changes go first and each one states what a user must do to upgrade.** This is the only section people actually need.
5. Suggest the semver bump and say why (breaking → major, new feature → minor, fixes only → patch).
6. If a `CHANGELOG.md` exists, prepend in its existing format. Otherwise print the markdown.
