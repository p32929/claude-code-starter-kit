---
description: Diagnose and fix a failing CI run or failing local test suite
argument-hint: "[optional: CI run URL or the failing job name]"
allowed-tools: Bash, Read, Grep, Glob, Edit
---

Branch: !`git branch --show-current`
Recent CI runs: !`gh run list --limit 5 2>/dev/null || echo "gh not available — I will work from local runs"`

What I gave you: $ARGUMENTS

## Your task

1. **Get the real failure output.** `gh run view <id> --log-failed`, or run the failing command locally. Never work from the summary line — it hides the cause.
2. **Reproduce locally** with the exact same command CI runs (read the workflow file to get it, including env vars and the node/python version).
3. **Classify it before fixing** — the fix is completely different per class:
   - **Real bug** — the code is wrong. Fix the code.
   - **Bad test** — the test asserts something that is no longer true. Fix the test, and say clearly why the old assertion was wrong.
   - **Flake** — timing, ordering, shared state, real network, real clock. Fix the *cause* (fake the clock, isolate state, seed randomness). **Never add a retry or a sleep to hide a flake.**
   - **Environment** — a version, a missing service, a cache, a missing secret. Fix the workflow, not the code.
4. Apply the fix and **re-run the exact failing command to prove it passes.** Paste the output.
5. If several tests fail, find the common cause first — it is usually one bug, not N.

Report: what failed, which class it was, the fix, and the passing output. If you could not reproduce it, say so plainly rather than guessing at a fix.
