---
description: Find dead code, unused dependencies, and duplication that can be deleted
argument-hint: "[optional: directory to scope to]"
allowed-tools: Bash, Read, Grep, Glob
---

Scope: $ARGUMENTS (default: the whole repo)

## Your task

Find what can be **deleted**. Deletion is the goal — not reorganisation.

1. **Unreferenced exports and files.** For each exported symbol, grep the repo for imports of it. Zero hits outside its own file = dead. Watch for dynamic imports and string-based references before declaring anything dead.
2. **Unused dependencies.** For each direct dependency in the manifest, grep for an import of it. Zero hits = removable.
3. **Commented-out code.** Git remembers it. Delete it.
4. **Duplicated logic** appearing 3+ times (2 is a coincidence).
5. **Reinvented standard library** — a hand-rolled deep clone, debounce, group-by, UUID, query-string parser, date formatter.
6. **Dead flags and config** — a boolean that is never false, an env var never read, a feature flag fully rolled out.
7. **Abandoned abstractions** — an interface with one implementation, a factory with one product, a wrapper that only forwards.

## Rules

- **Propose, with evidence.** Every item needs the grep result that proves it is unused. Do not delete anything you cannot prove.
- Flag anything risky to remove (public API, plugin entry point, dynamically referenced) as `VERIFY FIRST` rather than deleting.
- Give me the total line count that would disappear. That number is the point of this exercise.

Output a table: `what | where | evidence it is unused | lines saved | safe to delete?`
