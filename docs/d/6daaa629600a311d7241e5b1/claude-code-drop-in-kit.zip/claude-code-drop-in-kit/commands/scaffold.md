---
description: Create a new module/component/endpoint that matches this codebase's existing patterns
argument-hint: "<what to create, e.g. 'a POST /invoices endpoint' or 'a SettingsPanel component'>"
allowed-tools: Read, Grep, Glob, Write, Edit, Bash
---

Create: $ARGUMENTS

Project layout:
!`git ls-files | head -60`

## Your task

**Find the closest existing example and copy its shape.** That is the whole job. Consistency with this codebase beats any pattern you would choose on your own.

1. Locate 2-3 existing things of the same kind (another endpoint, another component, another model) and READ them fully.
2. Copy: their file location and naming, their imports, their error handling, their validation approach, their types, their export style, their test file location and style.
3. Write the new thing following that shape exactly. Wire it up where such things get registered (the router, the index, the barrel export, the DI container) — grep to find where the *existing* ones are registered and add yours in the same place.
4. Add a test alongside it, matching the existing test style.
5. Run whatever verifies it: typecheck, lint, the test.

Rules:
- **No new dependencies** unless I asked. Use what the project already has.
- No abstraction beyond what the existing examples have. Do not "improve" the pattern while adding to it.
- Report exactly which existing file you used as the template, and every file you created or touched.
