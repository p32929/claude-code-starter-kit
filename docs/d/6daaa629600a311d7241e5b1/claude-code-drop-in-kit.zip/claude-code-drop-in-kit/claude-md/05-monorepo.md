# <Project> — monorepo

<One sentence: what ships out of this repo.>

## Commands

Always run from the repo root. `<pnpm/turbo/nx>` handles the dependency graph.

| Task | Command |
|---|---|
| install | `pnpm install` |
| dev (all) | `pnpm dev` |
| dev (one) | `pnpm --filter <pkg> dev` |
| test (changed only) | `pnpm turbo test --filter='...[origin/main]'` |
| test one package | `pnpm --filter <pkg> test` |
| typecheck all | `pnpm turbo typecheck` |
| build all | `pnpm turbo build` |
| add dep to one package | `pnpm --filter <pkg> add <dep>` |

<!-- The filtered commands matter: on a large monorepo an unfiltered test run is minutes,
     and Claude will run it on every iteration unless told otherwise. -->

## Packages

```
apps/web        <what it is>   depends on: ui, shared
apps/api        <what it is>   depends on: shared, db
packages/ui     design system
packages/shared types + utilities used by both apps
packages/db     schema + client
```

## The dependency rule

**Dependencies flow one way: `apps/*` → `packages/*` → `packages/shared`.**

- An app may never import from another app.
- A package may never import from an app.
- No cycles between packages. If two packages need each other, the shared part belongs in
  a third one.

This rule is the entire reason the monorepo builds in parallel. Breaking it turns every
build into a full rebuild.

## Conventions

- Shared types live in `packages/shared` and are imported from there — **never redeclared**
  in an app. Duplicated types drifting apart is the characteristic monorepo bug.
- Every package has its own `package.json`, `tsconfig.json` (extending the root) and test
  setup.
- Internal deps use `workspace:*`, never a version number.
- A dependency used by one package is installed **in that package**, not at the root.
  Root-level deps are tooling only.

## Rules

- Never edit another package's files to fix a problem in yours — change your own usage, or
  change that package's public API deliberately and update **every** consumer in the same
  change.
- Changing a shared package's public API: grep every workspace for its usages first
  (`grep -rn "from '@repo/shared'" apps packages`). State how many consumers you found.
- Do not add a package to the root `package.json` to "make the import work". That hides a
  missing dependency and it will break in CI, not locally.

## Gotchas

- `pnpm install` at the root, always. Installing inside a package directory produces a
  broken nested `node_modules`.
- Turbo caches on inputs — if a task reads a file not listed in its `inputs`, you will get
  a stale cached result. Symptom: "it works locally but CI is wrong", or vice versa.
- A changed shared package needs a rebuild before dependent apps see it, unless the app
  consumes the source directly.
- CI must run with the same package manager version as local; pin it in `packageManager`.
