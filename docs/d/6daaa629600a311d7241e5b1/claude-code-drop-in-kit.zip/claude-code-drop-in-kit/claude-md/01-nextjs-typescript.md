# <Project> — Next.js + TypeScript

<One sentence: what this app is.>

## Commands

| Task | Command |
|---|---|
| dev | `pnpm dev` |
| test | `pnpm test` |
| test one file | `pnpm vitest run path/to/file.test.ts` |
| typecheck | `pnpm tsc --noEmit` |
| lint | `pnpm lint` |
| build | `pnpm build` |
| db migrate | `pnpm drizzle-kit push` |

## Stack

Next.js <15, App Router> · React <19> · TypeScript <5.x, strict> · Tailwind <v4> ·
<shadcn/ui> · <Drizzle + Postgres> · <Zod> · <Vitest + Testing Library> · pnpm

## Layout

```
app/                  routes — folder = URL segment
app/api/              route handlers
components/ui/        shadcn primitives — GENERATED, do not hand-edit
components/           our components
lib/                  shared utilities, db client, auth
server/               server-only code — never imported from a client component
types/                shared types
```

## Server vs client — the rule that matters most here

**Everything is a Server Component unless it needs interactivity.** Only add
`"use client"` when the file uses state, effects, event handlers, or a browser API.

- Put `"use client"` as low in the tree as possible. One at the top of a page turns the
  whole page into client JS.
- Never import from `server/` in a client component — it leaks secrets into the bundle.
- Data fetching belongs in Server Components. Do not `useEffect`-fetch what the server
  can render.
- Mutations go through Server Actions, and every action **re-validates its input with Zod
  and re-checks authorisation**. A Server Action is a public HTTP endpoint; the fact that
  it is only called from one button does not protect it.

## Conventions

- Components: `PascalCase.tsx`, one component per file, named exports.
- Everything else: `kebab-case.ts`.
- Imports use the `@/` alias, never `../../`.
- Types with `type`, not `interface`, unless declaration merging is needed.
- **No `any`.** Use `unknown` and narrow it.
- Zod schema at every boundary: form input, route handler body, env vars, external API
  responses.
- Errors: `error.tsx` per route segment; never swallow into a toast and carry on.

## Rules

- Do not edit `components/ui/*` — regenerate with `pnpm dlx shadcn@latest add <name>`.
- Do not add a state library. Server state comes from the server; local state is `useState`.
- Do not add a date library — use `Intl.DateTimeFormat`.
- No `dangerouslySetInnerHTML` without sanitising.
- Keep `any` and `@ts-expect-error` out of the diff.

## Gotchas

- `next/image` needs the remote host in `next.config.ts` `images.remotePatterns` or it 400s.
- Route handlers are cached by default in production — set `export const dynamic = 'force-dynamic'`
  for anything that reads per-request state.
- `NEXT_PUBLIC_*` env vars are **inlined into the browser bundle**. Never prefix a secret.
- Server Actions must be `async` and in a file with `"use server"` at the top.
- A `params`/`searchParams` prop is a Promise in App Router — `await` it.
