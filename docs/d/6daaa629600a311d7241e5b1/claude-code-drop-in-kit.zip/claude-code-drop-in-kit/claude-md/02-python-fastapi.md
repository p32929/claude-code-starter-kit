# <Project> — Python + FastAPI

<One sentence: what this service does.>

## Commands

| Task | Command |
|---|---|
| install | `uv sync` |
| dev | `uv run fastapi dev app/main.py` |
| test | `uv run pytest` |
| test one file | `uv run pytest tests/test_x.py::test_name -x` |
| lint + format | `uv run ruff check --fix . && uv run ruff format .` |
| typecheck | `uv run mypy app` |
| migrate | `uv run alembic upgrade head` |
| new migration | `uv run alembic revision --autogenerate -m "<msg>"` |

## Stack

Python <3.12> · FastAPI · Pydantic v2 · SQLAlchemy <2.0, async> · Alembic · asyncpg ·
pytest + pytest-asyncio · ruff · mypy · uv

## Layout

```
app/api/routes/       routers, one file per resource
app/models/           SQLAlchemy ORM models
app/schemas/          Pydantic request/response models
app/services/         business logic — no HTTP, no ORM session creation
app/core/             config, security, dependencies
alembic/versions/     migrations
tests/                mirrors app/
```

## Conventions

- **Routes are thin.** Parse, authorise, call a service, return. No business logic in a route.
- **Services never import FastAPI.** They take plain arguments and a session; that is what
  makes them testable and reusable from a worker or a CLI.
- ORM models and Pydantic schemas are **separate types**. Never return an ORM object
  directly — always through a `response_model`, or you will leak `password_hash` the day
  someone adds it.
- Async all the way down. A sync DB call inside an async route blocks the event loop and
  silently destroys throughput. If you must call sync code, `run_in_threadpool` it.
- Dependencies via `Depends()`, including the DB session — never a module-level session.
- Config is one `Settings(BaseSettings)` object in `app/core/config.py`. Never `os.getenv`
  scattered through the code.
- Type hints on every function signature. `mypy` must pass.

## Errors

Raise `HTTPException` at the route layer only. Services raise domain exceptions
(`InsufficientFunds`) which an exception handler maps to a status code. Every error
response has the same shape:

```json
{ "error": { "code": "insufficient_funds", "message": "...", "field": null } }
```

## Rules

- Every list endpoint is paginated from day one. Retrofitting pagination is breaking.
- No raw SQL string interpolation. Bound parameters or SQLAlchemy expressions only.
- No new dependency without asking; the stdlib usually has it.
- Do not edit generated Alembic migrations after they have been applied anywhere —
  write a new one.

## Gotchas

- Pydantic v2: it is `model_validate` / `model_dump`, and `ConfigDict`, not v1's `Config` class.
- `@lru_cache` on an async function does not do what you want — cache the sync inner function.
- SQLAlchemy 2.0 async: lazy-loading a relationship outside the session raises
  `MissingGreenlet`. Use `selectinload()` explicitly.
- `--autogenerate` misses table and column **renames** — it emits a drop plus an add, which
  destroys data. Always read the generated migration before applying it.
