# <Project> — Node API service

<One sentence: what this service does and who calls it.>

## Commands

| Task | Command |
|---|---|
| dev | `pnpm dev` |
| test | `pnpm test` |
| test one file | `pnpm vitest run src/x.test.ts` |
| typecheck | `pnpm tsc --noEmit` |
| lint | `pnpm lint` |
| migrate | `pnpm migrate` |
| build | `pnpm build` |

## Stack

Node <22> (ESM) · TypeScript strict · <Fastify/Express> · <Prisma/Drizzle> + Postgres ·
Zod · Vitest · pino · pnpm

## Layout

```
src/routes/       HTTP layer only
src/services/     business logic — no req/res, no framework imports
src/db/           schema, client, migrations
src/lib/          shared utilities
src/middleware/   auth, error handler, request id
```

## Conventions

- Routes parse and authorise, then delegate. **Never put business logic in a handler** —
  it becomes untestable and un-reusable the moment a cron job needs the same thing.
- Zod-validate every request body, query and param. Infer the type from the schema
  (`z.infer`) — never declare it twice.
- One error shape everywhere, and a machine-readable `code`:
  ```json
  { "error": { "code": "not_found", "message": "..." } }
  ```
- Async errors go to the central error handler. Never `catch` and `console.log`.
- Structured logging with pino, with a request id on every line. **Never log a request
  body, a token, or a password** — redact by key.
- Money is an integer in minor units. Timestamps are ISO-8601 UTC.

## Rules

- Every list endpoint paginated from day one.
- Every external call gets a timeout and a retry policy. A `fetch` with no timeout will
  eventually hang a worker.
- Graceful shutdown on SIGTERM: stop accepting, drain in-flight, close the pool.
- No secrets in code; read from env, validated once at boot by a Zod schema so the process
  dies immediately on a missing var rather than at 3am.
- No new dependency without asking.

## Gotchas

- ESM: relative imports need the `.js` extension even in TypeScript source.
- `JSON.parse` on untrusted input throws — always wrap it.
- Prisma generates types; run `pnpm prisma generate` after any schema change or the
  typecheck lies to you.
- A `for...of` with `await` inside runs serially. Use a bounded `Promise.all` when the
  iterations are independent.
- Unhandled promise rejections kill the process in Node 22. That is correct — do not
  suppress them, fix them.
