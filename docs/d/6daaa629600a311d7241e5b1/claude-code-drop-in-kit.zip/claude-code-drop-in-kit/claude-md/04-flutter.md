# <Project> — Flutter app

<One sentence: what this app does, and the platforms it targets.>

## Commands

| Task | Command |
|---|---|
| get deps | `flutter pub get` |
| run | `flutter run -d <device>` |
| test | `flutter test` |
| test one file | `flutter test test/x_test.dart` |
| analyze | `flutter analyze` |
| format | `dart format lib test` |
| codegen | `dart run build_runner build --delete-conflicting-outputs` |
| build android | `flutter build apk --release` |

## Stack

Flutter <3.x> · Dart <3.x> · <riverpod/bloc> · <go_router> · <dio> · <freezed + json_serializable>

## Layout

```
lib/features/<feature>/   screens, widgets, controller for one feature
lib/core/                 theme, router, constants, shared widgets
lib/data/                 models, repositories, api clients
lib/l10n/                 localisation
test/                     mirrors lib/
```

## Conventions

- **Feature-first**, not layer-first. Everything for one feature lives in one folder.
- Widgets are `const` wherever possible — this is the single biggest rebuild win.
- Use the **right widget for the role**, not a `GestureDetector` around everything:
  `IconButton` for a tappable icon, `TabBar` for tabs, `Divider` for a rule,
  `ListTile` for a list row, `Card`/`InkWell` for a tappable tile. Ink feedback is
  the difference between a native-feeling app and a web page.
- For a compact inline `IconButton`, set `padding: EdgeInsets.zero, constraints: const BoxConstraints()` —
  otherwise it claims a 48×48 hit target and breaks your layout.
- Models are `freezed` + `json_serializable`. Never hand-write `fromJson`.
- No business logic in a `build()` method. It runs on every frame.
- Colours and text styles come from `Theme.of(context)`, never hardcoded in a widget.

## Rules

- No `setState` in a feature that already has a state management solution — pick one.
- Never `BuildContext` across an `await` without an `if (!context.mounted) return;` first.
- `dispose()` every controller, stream subscription, and animation controller.
- No new package without asking; check `flutter analyze` is clean before finishing.

## Gotchas

- Generated files (`*.g.dart`, `*.freezed.dart`) are committed here — run codegen after
  touching any annotated model or the build breaks with a confusing error.
- Hot reload does not re-run `initState` or `main`. Hot **restart** after changing either.
- A `ListView` inside a `Column` needs `shrinkWrap: true` **plus** a bounded height, or
  you get an unbounded-constraints error.
- `flutter test` uses a fake 800×600 screen; golden tests differ across platforms unless
  you pin the font and the device size.
