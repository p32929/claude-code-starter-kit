#!/usr/bin/env bash
# Stop / Notification — tells you when Claude has finished or needs you.
# Useful when you run long tasks and switch to another window.
set -uo pipefail

event=$(cat | python3 -c 'import json,sys;print(json.load(sys.stdin).get("hook_event_name","Stop"))' 2>/dev/null) || event="Stop"
dir=$(basename "$PWD")

case "$event" in
  Notification) title="Claude needs you"; msg="$dir — waiting for input";;
  *)            title="Claude finished";  msg="$dir — task complete";;
esac

if [ "$(uname)" = "Darwin" ]; then
  osascript -e "display notification \"$msg\" with title \"$title\" sound name \"Glass\"" >/dev/null 2>&1
  # Want it spoken instead? uncomment:  say "$title" &
elif command -v notify-send >/dev/null 2>&1; then
  notify-send "$title" "$msg" >/dev/null 2>&1
else
  printf '\a' # terminal bell fallback
fi
exit 0
