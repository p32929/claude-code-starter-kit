#!/usr/bin/env bash
# PostToolUse (Bash) — appends every shell command Claude runs to a local log.
# Your audit trail for "what did it actually do in my repo?".
set -uo pipefail

log="${CLAUDE_CMD_LOG:-.claude/command-log.txt}"
mkdir -p "$(dirname "$log")" 2>/dev/null || exit 0

cat | python3 -c '
import json,sys,datetime
d=json.load(sys.stdin)
ti=d.get("tool_input") or {}
cmd=(ti.get("command") or "").replace("\n"," ⏎ ")
if not cmd: sys.exit(0)
res=d.get("tool_response") or {}
code=res.get("exit_code") if isinstance(res,dict) else ""
ts=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
print(f"{ts}  [exit {code}]  {cmd}")
' >> "$log" 2>/dev/null
exit 0
