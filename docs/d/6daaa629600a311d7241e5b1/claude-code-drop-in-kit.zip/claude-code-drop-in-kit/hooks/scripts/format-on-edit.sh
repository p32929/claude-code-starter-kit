#!/usr/bin/env bash
# PostToolUse (Edit|Write|MultiEdit) — formats the file that was just written.
# Silent and best-effort: never blocks, never fails the tool call.
set -uo pipefail

f=$(cat | python3 -c 'import json,sys;print((json.load(sys.stdin).get("tool_input") or {}).get("file_path",""))' 2>/dev/null) || exit 0
[ -f "$f" ] || exit 0

has() { command -v "$1" >/dev/null 2>&1; }

case "$f" in
  *.ts|*.tsx|*.js|*.jsx|*.mjs|*.cjs|*.json|*.css|*.scss|*.html|*.md|*.yml|*.yaml)
      if has biome; then biome format --write "$f"
      elif [ -x node_modules/.bin/prettier ]; then node_modules/.bin/prettier --write "$f"
      elif has prettier; then prettier --write "$f"
      fi ;;
  *.py) if has ruff; then ruff format "$f"; ruff check --fix --quiet "$f"
        elif has black; then black -q "$f"; fi ;;
  *.go)   has gofmt   && gofmt -w "$f" ;;
  *.rs)   has rustfmt && rustfmt --edition 2021 "$f" ;;
  *.rb)   has rubocop && rubocop -a --stderr --format quiet "$f" ;;
  *.php)  has php-cs-fixer && php-cs-fixer fix "$f" ;;
  *.java) has google-java-format && google-java-format -i "$f" ;;
  *.sh)   has shfmt   && shfmt -w "$f" ;;
  *.dart) has dart    && dart format "$f" ;;
  *.swift) has swiftformat && swiftformat "$f" ;;
esac >/dev/null 2>&1
exit 0
