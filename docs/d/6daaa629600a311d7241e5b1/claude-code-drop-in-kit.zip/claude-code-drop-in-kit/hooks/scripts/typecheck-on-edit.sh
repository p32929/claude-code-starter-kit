#!/usr/bin/env bash
# PostToolUse (Edit|Write|MultiEdit) — typechecks after a source edit and feeds
# any errors straight back to Claude so it fixes them in the same turn.
# Exit 2 sends stderr to Claude. Skips silently when there is nothing to run.
set -uo pipefail

f=$(cat | python3 -c 'import json,sys;print((json.load(sys.stdin).get("tool_input") or {}).get("file_path",""))' 2>/dev/null) || exit 0
[ -f "$f" ] || exit 0

out=""; rc=0
case "$f" in
  *.ts|*.tsx)
      [ -f tsconfig.json ] || exit 0
      if   [ -x node_modules/.bin/tsc ]; then out=$(node_modules/.bin/tsc --noEmit -p . 2>&1); rc=$?
      elif command -v tsc >/dev/null 2>&1; then out=$(tsc --noEmit -p . 2>&1); rc=$?
      else exit 0; fi ;;
  *.py)
      if   command -v mypy >/dev/null 2>&1 && { [ -f mypy.ini ] || grep -q '\[tool.mypy\]' pyproject.toml 2>/dev/null; }; then
           out=$(mypy "$f" 2>&1); rc=$?
      elif command -v ruff >/dev/null 2>&1; then out=$(ruff check "$f" 2>&1); rc=$?
      else exit 0; fi ;;
  *.go) command -v go >/dev/null 2>&1 || exit 0; out=$(go build ./... 2>&1); rc=$? ;;
  *.rs) command -v cargo >/dev/null 2>&1 || exit 0; out=$(cargo check --quiet 2>&1); rc=$? ;;
  *) exit 0 ;;
esac

if [ $rc -ne 0 ]; then
  echo "Type/lint errors after editing $f — fix these now, before moving on:" >&2
  printf '%s\n' "$out" | head -40 >&2
  exit 2
fi
exit 0
