#!/usr/bin/env bash
# PreToolUse (Bash) — stops commits and pushes straight to the default branch.
set -uo pipefail

cmd=$(cat | python3 -c 'import json,sys;print((json.load(sys.stdin).get("tool_input") or {}).get("command",""))' 2>/dev/null) || exit 0
printf '%s' "$cmd" | grep -Eq 'git[[:space:]]+(commit|push)' || exit 0

branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null) || exit 0

# Edit this list for your team.
case "$branch" in
  main|master|develop|prod|production)
    echo "BLOCKED by protect-main hook: you are on '$branch', a protected branch." >&2
    echo "Create a feature branch first:  git checkout -b <type>/<short-description>" >&2
    echo "Then re-run the commit." >&2
    exit 2
    ;;
esac
exit 0
