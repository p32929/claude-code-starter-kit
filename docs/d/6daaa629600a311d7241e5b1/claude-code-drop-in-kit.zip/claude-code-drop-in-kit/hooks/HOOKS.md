# Hooks — what each one does, and how to turn it off

Hooks are shell scripts Claude Code runs automatically at fixed points. They are the
only part of Claude Code that can **stop** it doing something, rather than asking it nicely.

All seven here read the hook JSON from stdin with `python3` (present on every Mac and
Linux box) — no `jq` needed.

| Script | Fires on | What it does | Can block? |
|---|---|---|---|
| `guard-secrets.sh` | PreToolUse: Read/Edit/Write/Bash | Refuses to touch `.env`, `id_rsa`, `.pem`, `.aws/credentials`, `.npmrc`, `secrets.yaml` and friends | **Yes** |
| `guard-destructive.sh` | PreToolUse: Bash | Blocks `rm -rf /`, `git reset --hard`, `git clean -fd`, force-push to main, `DROP TABLE`, `DELETE` with no `WHERE`, `terraform destroy`, fork bombs | **Yes** |
| `protect-main.sh` | PreToolUse: Bash | Blocks `git commit` / `git push` while you are on `main`/`master`/`develop`/`prod` | **Yes** |
| `format-on-edit.sh` | PostToolUse: Edit/Write | Formats the file just written (biome/prettier/ruff/black/gofmt/rustfmt/rubocop/shfmt/dart/swiftformat) | No |
| `typecheck-on-edit.sh` | PostToolUse: Edit/Write | Runs `tsc --noEmit` / `mypy` / `ruff` / `go build` / `cargo check` and **feeds the errors back to Claude** so it fixes them in the same turn | **Yes** (by design) |
| `log-session.sh` | PostToolUse: Bash | Appends every shell command + exit code to `.claude/command-log.txt` | No |
| `notify-done.sh` | Stop / Notification | Desktop notification when Claude finishes or needs you | No |

## How blocking works

A hook that exits **2** blocks the tool call, and whatever it printed to **stderr is sent
back to Claude** — so the message is an instruction, not just a wall. That is why every
guard here explains what to do instead. Any other exit code lets the call through.

`typecheck-on-edit.sh` uses this deliberately: instead of you finding type errors twenty
minutes later, Claude sees them the instant it saves and fixes them before moving on.
It is the single highest-value hook in this pack.

## Install

```bash
mkdir -p .claude/hooks
cp hooks/scripts/*.sh .claude/hooks/
chmod +x .claude/hooks/*.sh
```

Then merge `settings.hooks.json` into `.claude/settings.json` (or `~/.claude/settings.json`
for every project). If you have no settings file yet, just copy it:

```bash
cp hooks/settings.hooks.json .claude/settings.json
```

**Restart Claude Code, or run `/hooks`** — hooks are captured at startup, so an already
running session will not pick them up.

## Verify it works

```bash
echo '{"tool_input":{"command":"rm -rf /"}}' | .claude/hooks/guard-destructive.sh; echo "exit=$?"
# -> exit=2  and a BLOCKED message
echo '{"tool_input":{"command":"ls"}}' | .claude/hooks/guard-destructive.sh; echo "exit=$?"
# -> exit=0  and silence
```

If a hook misbehaves in a real session, `claude --debug` prints every hook invocation
and its exit code.

## Turning one off

Delete its block from `settings.json`. That is the whole procedure — the scripts do
nothing on their own.

Two you may well want off on day one:

- **`protect-main.sh`** — infuriating on a solo repo where you commit straight to `main`.
  Either drop it, or edit its `case` list to only the branches you actually protect.
- **`typecheck-on-edit.sh`** — on a large TypeScript repo a full `tsc -p .` on every save
  is slow. Keep it if your project typechecks in a few seconds; drop it if it does not.

## Customising

- **`guard-secrets.sh`** — the `BLOCKED` variable is one extended regex. Add your own
  patterns with `|`.
- **`guard-destructive.sh`** — each rule is one `grep` line calling `deny`. Add or delete
  lines freely; they are independent.
- **`protect-main.sh`** — edit the `case "$branch" in` list.
- **`format-on-edit.sh`** — one `case` arm per extension. Add your language in the same shape.
- **`log-session.sh`** — set `CLAUDE_CMD_LOG` to change where the log goes.
  Add `.claude/command-log.txt` to `.gitignore`.

## A warning worth reading

Hooks run **with your full user permissions, automatically, with no confirmation**. That is
what makes them useful and what makes them dangerous. Read any hook before you install it —
including these. Every script in this pack is plain, commented bash with no network calls
and no dependencies, precisely so you can check that claim in about two minutes.
