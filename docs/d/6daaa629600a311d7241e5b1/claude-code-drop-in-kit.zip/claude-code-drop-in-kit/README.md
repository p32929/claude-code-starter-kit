# Claude Code Drop-In Kit

**39 working files for Claude Code. Copy them into `.claude/`, restart, done.**

Not a PDF. Not a course. Not 91 pages about what a subagent is. These are the actual
files — subagents, slash commands, hooks, skills and CLAUDE.md templates — that you drop
into a project and use in the next thirty seconds.

Every hook in this pack was executed and tested before it shipped. See `hooks/HOOKS.md`
for the test commands so you can verify that yourself.

---

## Install (60 seconds)

```bash
cd /path/to/your/project
bash /path/to/this/kit/install.sh
```

Then **restart Claude Code** (hooks are read at startup) and type `/` to see the new commands.

Prefer to do it by hand? It is four `cp` commands — see `INSTALL.md`.

Install into `~/.claude/` instead of `./.claude/` and everything is available in **every**
project you ever open:

```bash
bash install.sh --global
```

---

## What is in the box

### 10 subagents → `agents/`

Specialists Claude hands work to. Invoke one by name ("use the bug-hunter subagent") or let
Claude pick based on the description.

| Agent | What it is for |
|---|---|
| `bug-hunter` | Root cause, not symptom. Traces the bad value back to where it first went wrong. |
| `test-writer` | Tests in **your** existing framework and style. Runs them. Pastes real output. |
| `code-reviewer` | Real defects only. No style opinions. Catches the callers you forgot to update. |
| `refactorer` | Shape changes with behaviour locked. Deletes more than it adds. |
| `api-designer` | Route tables, status codes, one error shape, pagination from day one. |
| `sql-tuner` | N+1s, missing indexes, `EXPLAIN` plans. Measures before and after. |
| `perf-profiler` | Finds where the time actually goes before changing a line. |
| `dependency-auditor` | What you can delete, what is abandoned, what the stdlib already does. |
| `migration-planner` | Expand/contract. Every step gets a rollback. |
| `docs-writer` | Docs written from the code, with examples that actually run. |

### 12 slash commands → `commands/`

| Command | What it does |
|---|---|
| `/commit` | Reads the real diff, writes a message in your repo's existing style. Refuses to commit secrets. |
| `/pr` | Pushes and opens the PR with what / why / how to test / risk. |
| `/review` | Reviews the diff, then greps for callers of every changed signature. |
| `/debug <symptom>` | Root-cause hunt. Reproduce, trace, minimal fix, verify. |
| `/fix-ci` | Pulls the real CI failure, reproduces it locally, classifies it, fixes it, re-runs. |
| `/tests` | Tests for what changed, in your framework. |
| `/security` | Exploitable issues in the diff. Concrete exploit or it does not get reported. |
| `/cleanup` | Dead code, unused deps, duplication — with the grep proving each one. |
| `/explain <thing>` | How it really works, with `file:line` for every claim. |
| `/scaffold <thing>` | New module matching your existing patterns, wired up, with a test. |
| `/onboard` | Maps an unfamiliar repo: stack, commands, the 5 files that matter, the landmines. |
| `/changelog` | Release notes from commits, written from the user's point of view. |

### 7 hooks → `hooks/`

The only part of Claude Code that can **stop** it, rather than asking it nicely.

- **`guard-secrets`** — refuses to read or write `.env`, `id_rsa`, `.pem`, `.aws/credentials`, `.npmrc`…
- **`guard-destructive`** — blocks `rm -rf /`, `git reset --hard`, `git clean -fd`, force-push to main, `DROP TABLE`, `DELETE` with no `WHERE`, `terraform destroy`, fork bombs
- **`protect-main`** — no commits or pushes while you are on `main`
- **`format-on-edit`** — formats every file Claude writes (biome, prettier, ruff, black, gofmt, rustfmt, rubocop, shfmt, dart, swiftformat)
- **`typecheck-on-edit`** — runs `tsc --noEmit` / `mypy` / `go build` / `cargo check` after each edit and **feeds the errors straight back to Claude so it fixes them in the same turn.** The highest-value file in this pack.
- **`log-session`** — every shell command + exit code to `.claude/command-log.txt`
- **`notify-done`** — desktop notification when Claude finishes or needs you

All seven are plain commented bash, no dependencies beyond `python3`, no network calls.
Read them before you install them — you should do that with anyone's hooks, including these.

### 4 skills → `skills/`

Multi-step procedures Claude loads when the situation matches.

- **`ship-it`** — the full pre-merge gate: build, typecheck, tests, review, security, leftovers, migration safety, PR description. Stops at the first blocker.
- **`incident-triage`** — production is down *right now*. Stop the bleeding, then root-cause. Rollback-first.
- **`spec-to-plan`** — turns a vague request into a plan of shippable, revertible steps grounded in real files. Including the answer "do not build this".
- **`legacy-rescue`** — characterisation tests before touching untested legacy code, so you can tell a fix from a regression.

### 6 CLAUDE.md templates → `claude-md/`

Project memory, filled in and ready: universal base, Next.js + TypeScript, Python + FastAPI,
Node API, Flutter, monorepo. Each has the commands table, the conventions, and — the part
that actually saves you money — a **Gotchas** section of the mistakes that repo makes over
and over.

---

## Where to start

1. `claude-md/00-universal.md` → your repo's `CLAUDE.md`. Fill in the commands table. This
   one file is the biggest single improvement most people can make.
2. `hooks/scripts/typecheck-on-edit.sh` — stop finding type errors twenty minutes late.
3. `/onboard` on a repo you do not know.
4. `/review` before your next PR.

## Requirements

Claude Code, `bash`, `python3` (already on every Mac and Linux machine), and `git`.
Windows: works under WSL.

## Licence

One developer, unlimited personal and commercial projects. Modify freely. Do not resell or
redistribute the files. Full terms in `LICENSE.txt`.
