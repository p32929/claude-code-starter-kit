#!/usr/bin/env bash
# Claude Code Drop-In Kit — installer
#
#   bash install.sh            install into ./.claude  (this project only)
#   bash install.sh --global   install into ~/.claude  (every project)
#
# Never overwrites an existing settings.json.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "${1:-}" = "--global" ]; then
  DEST="$HOME/.claude"; SCOPE="global (every project)"
else
  DEST="$PWD/.claude";  SCOPE="this project ($PWD)"
fi

echo "Claude Code Drop-In Kit"
echo "Installing to: $DEST   [$SCOPE]"
echo

mkdir -p "$DEST/agents" "$DEST/commands" "$DEST/skills" "$DEST/hooks"

cp "$SRC"/agents/*.md        "$DEST/agents/"
cp "$SRC"/commands/*.md      "$DEST/commands/"
cp -R "$SRC"/skills/.        "$DEST/skills/"
cp "$SRC"/hooks/scripts/*.sh "$DEST/hooks/"
chmod +x "$DEST"/hooks/*.sh

printf '  %-12s %s\n' \
  "agents"   "$(ls -1 "$SRC"/agents/*.md | wc -l | tr -d ' ') subagents" \
  "commands" "$(ls -1 "$SRC"/commands/*.md | wc -l | tr -d ' ') slash commands" \
  "skills"   "$(ls -1d "$SRC"/skills/*/ | wc -l | tr -d ' ') skills" \
  "hooks"    "$(ls -1 "$SRC"/hooks/scripts/*.sh | wc -l | tr -d ' ') hook scripts"

echo
if [ -f "$DEST/settings.json" ]; then
  cp "$SRC/hooks/settings.hooks.json" "$DEST/settings.hooks.json"
  echo "  !  $DEST/settings.json already exists — NOT overwritten."
  echo "     Merge the \"hooks\" block from $DEST/settings.hooks.json into it,"
  echo "     then delete settings.hooks.json. Hooks are OFF until you do."
else
  cp "$SRC/hooks/settings.hooks.json" "$DEST/settings.json"
  echo "  settings.json  written (hooks enabled)"
fi

echo
echo "Self-test:"
if printf '{"tool_input":{"command":"rm -rf /"}}' | "$DEST/hooks/guard-destructive.sh" >/dev/null 2>&1; then
  echo "  FAIL  guard-destructive did not block 'rm -rf /' — check python3 is installed."
else
  echo "  ok    guard-destructive blocks 'rm -rf /'"
fi
if printf '{"tool_input":{"file_path":".env"}}' | "$DEST/hooks/guard-secrets.sh" >/dev/null 2>&1; then
  echo "  FAIL  guard-secrets did not block '.env'"
else
  echo "  ok    guard-secrets blocks '.env'"
fi

echo
echo "Next:"
echo "  1. RESTART Claude Code  (hooks are only read at startup)"
echo "  2. Type  /  to see the new commands"
echo "  3. Copy a project memory template:"
echo "       cp $SRC/claude-md/00-universal.md CLAUDE.md"
echo "  4. Read hooks/HOOKS.md — two hooks (protect-main, typecheck-on-edit)"
echo "     are opinionated and you may want them off."
echo
echo "Done."
